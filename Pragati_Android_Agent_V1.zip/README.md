# Pragati Android Agent V1

यह पहला native Android foundation है।
- Native Android app
- RECORD_AUDIO permission
- Microphone foreground service
- Persistent foreground notification
- Start/Stop Agent buttons

अगले चरण में इसी service में voice recognition, AI connection, spoken response और approved actions जोड़े जाएंगे।

महत्वपूर्ण: Android के आधुनिक versions में microphone foreground service को user-visible app से शुरू करना और आवश्यक permissions लेना पड़ता है। इसलिए "background agent" का मतलब छिपकर microphone चलाना नहीं है; Android की foreground-service notification दिखाई देगी।
