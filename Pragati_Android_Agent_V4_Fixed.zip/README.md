# Pragati Android Agent V2

Native Android foundation for Pragati.

## GitHub APK build
1. Put the contents of this project at the repository root.
2. Open Actions.
3. Select Build Pragati APK.
4. Run workflow.
5. Open the completed run and download Pragati-debug-apk.
6. Extract and install app-debug.apk.

Current foundation: native Android app, microphone permission, foreground microphone service, persistent notification, start/stop controls.

Next: voice recognition, AI brain, speech output, and approved device actions.
