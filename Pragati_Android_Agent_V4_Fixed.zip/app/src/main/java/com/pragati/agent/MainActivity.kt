package com.pragati.agent

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity: ComponentActivity() {
    private val req=100
    override fun onCreate(b:Bundle?){ super.onCreate(b); setContentView(R.layout.activity_main)
        val status=findViewById<TextView>(R.id.status)
        findViewById<Button>(R.id.start).setOnClickListener {
            if(ContextCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){
                ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.RECORD_AUDIO),req)
            } else startAgent(status)
        }
        findViewById<Button>(R.id.stop).setOnClickListener {
            stopService(Intent(this,PragatiVoiceService::class.java)); status.text="Agent बंद है।"
        }
    }
    override fun onRequestPermissionsResult(r:Int,p:Array<out String>,g:IntArray){ super.onRequestPermissionsResult(r,p,g)
        if(r==req && g.isNotEmpty() && g[0]==PackageManager.PERMISSION_GRANTED) startAgent(findViewById(R.id.status))
    }
    private fun startAgent(status:TextView){
        ContextCompat.startForegroundService(this,Intent(this,PragatiVoiceService::class.java))
        status.text="Pragati background voice service चालू है।"
    }
}