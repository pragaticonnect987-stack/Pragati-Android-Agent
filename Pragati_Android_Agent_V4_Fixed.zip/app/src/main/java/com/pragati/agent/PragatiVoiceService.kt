package com.pragati.agent

import android.app.*
import android.content.Intent
import android.os.IBinder
import androidx.core.app.NotificationCompat

class PragatiVoiceService: Service() {
    override fun onCreate(){ super.onCreate()
        val ch="pragati_agent"
        getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(ch,"Pragati Agent",NotificationManager.IMPORTANCE_LOW))
        val n=NotificationCompat.Builder(this,ch)
            .setContentTitle("Pragati Agent")
            .setContentText("Pragati voice agent सक्रिय है")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true).build()
        startForeground(10,n)
    }
    override fun onStartCommand(i:Intent?,flags:Int,id:Int):Int { return START_STICKY }
    override fun onBind(i:Intent?):IBinder?=null
}